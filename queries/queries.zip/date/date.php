<?php
require_once "public.php";
$arr = null;
$cod = 0;
$txt = '';
$msg = '';

$arr = jdate("Y/n/d");
$cod = 200;
$txt = 'OK';
//__________________________________________END__________________________________________________
require_once "echoJson.php";
?>
